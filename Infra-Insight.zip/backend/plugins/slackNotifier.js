
module.exports = {
  init() {
    console.log("Slack notifier loaded");
  }
};
