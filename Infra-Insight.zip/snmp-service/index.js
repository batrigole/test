
console.log("SNMP Polling Service Started");
setInterval(() => {
  console.log("Polling devices...");
}, 5000);
