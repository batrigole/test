
export default function TopologyPage() {
  return (
    <div>
      <h1>Infrastructure Topology</h1>
      <p>Topology graph will render here.</p>
    </div>
  );
}
