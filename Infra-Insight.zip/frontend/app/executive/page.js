
export default function ExecutiveDashboard() {
  return (
    <div>
      <h1>Executive Overview</h1>
      <p>Infrastructure Health: 92%</p>
      <p>Active Alerts: 3</p>
    </div>
  );
}
